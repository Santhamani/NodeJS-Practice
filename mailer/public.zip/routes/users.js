var express = require('express');
var router = express.Router();
const nodemailer = require('nodemailer');

// create reusable transporter object using the default SMTP transport--from mailid
let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'snth.ammu@gmail.com',
        pass : 'sanu@1993'
        
    }
});

/ GET users listing./
router.post('/', function(req, res, next) {

console.log(req.body.email)
// // setup email data with unicode symbols
let mailOptions = {
    from: req.body.name + '&lt;' + req.body.email + '&gt;',//'"MEAN stack"', // sender address
    to: 'sravanthidarapu@gmail.com', // list of receivers
    subject: req.body.subject,//'Hello ✔', // Subject line
    //text: 'Hello world ?', // plain text body
    html: '<b>Hello world ?</b>' // html body
};
// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log(error);
    }
    console.log('Message %s sent: %s', info.messageId, info.response);  
    res.send('Message %s sent: %s', info.messageId, info.response);
});

});

router.get('/', function(req, res, next){
    res.render('users');
});

router.get('/admin', function(req, res, next) {
  res.redirect("/users")
});

module.exports = router;