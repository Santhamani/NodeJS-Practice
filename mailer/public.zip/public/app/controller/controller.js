

angular.module('myApp').controller('myCtrl',['$scope','$http',function($scope,$http){
   /* $scope.uploadfile = function(){
        var file = $scope.myFile;
        console.dir(file);
        var upload = "/profileCreate";
        fileupload.uploadFiletoUrl(file,uploadUrl);

    };*/

    $scope.sendEmail = function(email){
        $http.post('/users',{email:email})
            .then(function(data){
                alert('email sent');

            }).catch(function(err){
                console.log(err);
            })
    }
}]);