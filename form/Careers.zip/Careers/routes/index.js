
var express = require('express');
var router = express.Router();
var admin = require('../models/admin'); 
var dashboard = require('../models/dashboard'); 
var http = require("http")
var Sessions = require("sessions")
var passport = require('passport');
LocalStrategy = require('passport-local').Strategy;
console.log(admin)

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/dashboard', function(req, res, next) {
  res.render('dashboard', { title: 'Express' });
});

router.get('/careers', function(req, res, next) {
  dashboard.find({},function(err, data){
res.render('careers', { jobdata: data });
  });
});

router.get('/update', function(req, res, next){
  dashboard.find({},function(err, data){
  res.render('update', { editdata : data });
  });
});

router.get('/update/:$_id', function(req, res, next){
  var _id = req.params.$_id.toString();
  dashboard.remove({'$_id':_id},function(err, data){
   	if(err) res.json(err);
		else res.redirect('/update');
    });
});

/*router.get('/update/:$_id', function(req, res, next){
  dashboard.findByIdAndUpdate({_id:req.params.job_id},function(err, data){
   	if(err) res.json(err);
		else    res.redirect('/update');
    });
});*/
router.get('/fetchdata', function(req, res, next){
  var _id = req.query._id;
  dashboard.find({$_id:req.body.job_id},function(err, data){
    console.log(req,body);
   	if(err) res.json(err);
		else    res.redirect('/update');
    });
});


router.get('/login', function(req, res, next){
      res.render('index',{ title: 'Careers' });
     //req.session.destroy(function(){
     //res.redirect('/');
//});
});

router.post('/jobpost', function(req, res, next) {
  //res.render('dashboard')
 console.log(req.body)
 //res.render('careers', req.body);
dashboard({

      _id: req.body.job_id,
      job_title : req.body.job_title,
      role : req.body.role,
      location : req.body.location,
      experience : req.body.experience,
      salary: req.body.salary,
      job_type : req.body.job_type,
      skills : req.body.skills,
      job_description : req.body.job_description
}).save(function(err,data){
  console.log(err);
    if(err)
     res.json(err);
    else//
    console.log(data)
    //res.send("Succesfully inserted");
     res.render('dashboard.ejs', data);
 });
});

router.post('/update', function(req, res, next) {
  //res.render('dashboard')
 console.log(req.body)
 //res.render('careers', req.body);
dashboard({

      _id: req.body.job_id,
      job_title : req.body.job_title,
      role : req.body.role,
      location : req.body.location,
      experience : req.body.experience,
      salary: req.body.salary,
      job_type : req.body.job_type,
      skills : req.body.skills,
      job_description : req.body.job_description
}).update(function(err,data){
  console.log(err);
    if(err)
     res.json(err);
    else//
    console.log(data)
    //res.send("Succesfully inserted");
     res.render('update.ejs', data);
 });
});

router.post('/dashboard', function(req, res, next) {
    // res.render('/dashboard');
    console.log(req.body)
admin({
   email : req.body.email,
   password : req.body.password
 }).save(function(err,data){
  console.log(err);
    if(err)
     res.json(err);
    else//
    // res.send("Succesfully inserted");
     res.render('dashboard.ejs');
 });
/*admin.find({}, function(err, data){
 if( 'data.email' == req.body.email && 'data.password' == req.body.password )
 {
  res.render('dashboard.ejs');
 
  console.log(err);
}
});*/
/*
passport.use(new LocalStrategy(
  function(email, password, done) {
    User.findOne({ email : email }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!user.validPassword(password)) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
     
    });  res.render('dashboard');
  }
));*/

});


module.exports= router;
