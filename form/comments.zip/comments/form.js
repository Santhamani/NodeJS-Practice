
var titles = [];
var titleInput = document.getElementById("comments");
var messageBox = document.getElementById("display");
var names = [];
var nameInput = document.getElementById("name");
var nameBox = document.getElementById("commentname");

function Allow()
{
if (!user.title.value.match(/[a-zA-Z]$/) && user.title.value !="")
{
user.title.value="";
alert("Please Enter only alphabets");
}

window.location.reload()

if (!user.name.value.match(/[a-zA-Z]$/) && user.name.value !="")
{
user.name.value="";
alert("Please Enter only alphabets");
}
window.location.reload()    
}

function insert () {
titles.push(titleInput.value);
names.push(nameInput.value);
clearAndShow();
}

function clearAndShow () 
{
titleInput.value = "";
messageBox.innerHTML = "";
messageBox.innerHTML += " " + titles.join("<br/> ") + "<br/>";
nameInput.value = "";
nameBox.innerHTML = "";
nameBox.innerHTML += " " + names.join("<br/> ") + "<br/>";

}

