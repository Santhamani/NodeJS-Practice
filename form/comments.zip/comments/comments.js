var module = angular.module('app', []);

module.controller('CommentsCtrl', function ($scope, CommentService) {
 
    $scope.comment = CommentService.list();
 
    $scope.saveComment = function () {
		alert($scope.newcomment.id);
        CommentService.save($scope.newcomment);
        $scope.newcomment = {};
    }
}

module.service('CommentService', function () {
    var uid = 1;
    var comments = [{
        id:0,
        'name': 'asdf',
        'text': 'hello world',
        approved: true
      },
      {
        id:1,
        'name': 'xyz',
        'text': 'lorem ipsum',
        approved: false
      }
	
	];
    
    this.save = function (comments) {
		alert(comments.id);
        if (comments.id == null) {
            
            comments.id = uid++;
            comments.push(comments);
        } else {
            
			alert(comments.id);
            for (i in comments) {
                if (comments[i].id == comments.id) {
                    comments[i] = comments;
                }
            }
        }
 
    }
 
    this.get = function (id) {
        for (i in comments) {
            if (comments[i].id == id) {
                return comments[i];
            }
        }
 
    }
    
    this.delete = function (id) {
        for (i in comments) {
            if (comments[i].id == id) {
                comments.splice(i, 1);
            }
        }
    }
 
    this.list = function () {
        return comments;
    }
});
 
 module.filter("substring",function(){

	return function(val,findex,lindex){
		return val.substring(findex,lindex);
	}
	
 });
 